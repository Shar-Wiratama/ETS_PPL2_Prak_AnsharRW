<?php

namespace App\Models;

use CodeIgniter\Model;

class m_barang extends Model
{
    protected $table      = 'tbl_barang';
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;
    protected $allowedFields = ['nama_brg', 'harga_brg', 'stok', 'link_gambar'];

    function getBarang($data)
    {
        $db = \Config\Database::connect();
        $search = $data['nama_barang'];
        $data = $db->query("select * from tbl_barang where nama_brg like '%$search%' order by id")->getResultArray();
        return $data;
    }


    function storeBarang($data)
    {
        $nama_brg = $data['nama_brg'];
        $harga_brg = $data['harga_brg'];
        $stok = $data['stok'];
        $link_gambar = $data['link_gambar'];

        $dataBerkas = $link_gambar;
        $fileName = $dataBerkas->getRandomName();
        $db = \Config\Database::connect();

        if ($link_gambar->getName() !== "") {
            $result = $db->query("insert into tbl_barang (nama_brg, harga_brg, stok, link_gambar)
            values('$nama_brg', '$harga_brg', '$stok', '$fileName')");
            if ($result) {
                $dataBerkas->move('uploads/foto/', $fileName);
            }
        } else {
            $result = $db->query("insert into tbl_barang (nama_brg, harga_brg, stok, link_gambar) 
            values('$nama_brg', '$harga_brg', '$stok', '$link_gambar')");
        }

        return $result;
    }

    function getDetailBarang($id)
    {
        $db = \Config\Database::connect();
        $result = $db->query("select * from tbl_barang where id = $id")->getResultArray();

        return $result;
    }

    function deleteBarang($barang)
    {
        $db = \Config\Database::connect();
        if ($barang['link_gambar'] !== "") {
            unlink('./uploads/foto/' . $barang['link_gambar']);
        }
        $id = $barang['id'];
        $result = $db->query("delete from tbl_barang where id = $id");

        return $result;
    }

    function searchBarang($data)
    {
        $db = \Config\Database::connect();
        $search = $data['nama_brg'];
        $data = $db->query("select * from tbl_barang where nama like '%$search%' order by id")->getResultArray();
        return $data;
    }

    function updateBarang($data)
    {
        $db = \Config\Database::connect();
        $id = $data['id'];
        $nama_brg = $data['nama_brg'];
        $harga_brg = $data['harga_brg'];
        $stok = $data['stok'];
        $link_gambar = $data['link_gambar'];

        $dataBerkas = $link_gambar;
        $fileName = $dataBerkas->getRandomName();
        $db = \Config\Database::connect();
        if ($link_gambar->getName() !== "") {
            $result = $db->query("update tbl_barang set nama_brg='$nama_brg', harga_brg='$harga_brg', stok='$stok', link_gambar='$fileName' where id = '$id'");
            if ($result) {
                $dataBerkas->move('uploads/foto/', $fileName);
                if ($data['foto_lama'] !== "") {
                    unlink('./uploads/foto/' . $data['foto_lama']);
                }
            }
        } else {
            $result = $db->query("update tbl_barang set  nama_brg='$nama_brg', harga_brg='$harga_brg', stok='$stok' where id = '$id'");
        }

        return $result;
    }
}
