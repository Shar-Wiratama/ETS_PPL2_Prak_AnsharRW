<div class="col-lg-4">
        <div class="trending">
          <h3>Chart Harga Barang</h3>
          <ul class="trending-post">
            <li>
              <canvas id="myChart"></canvas>
            </li>
          </ul>
        </div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  <?php
  $js_array_jtb = json_encode($grafik_barang);
  echo "var dataobj = " . $js_array_jtb . ";\n";
  ?>

  var labels = []
  var dataarray = []

  dataobj.data.map(function(data) {
    labels.push(data.nama_brg);
    dataarray.push(data.harga_brg);
  });

  console.log(labels);
  console.log(dataarray);
  const data = {
    labels: labels,
    datasets: [{
      label: 'Harga Barang',
      backgroundColor: '#000',
      borderColor: '#000',
      data: dataarray,
    }]
  };

  const config = {
    type: 'line',
    data: data,
    options: {
      scales: {
        x: {
          grid: {
            display: false
          }
        },
        y: {
          suggestedMax: 0,
          beginAtZero: true,
          ticks: {
            maxTicksLimit: 6,
          },
          grid: {
            drawBorder: false,
          },
        },
      },
      datasets: {
        bar: {
          barThickness: 30
        }
      }
    }
  };
</script>
<script>
  const myChart = new Chart(
    document.getElementById('myChart'),
    config
  );
</script>
