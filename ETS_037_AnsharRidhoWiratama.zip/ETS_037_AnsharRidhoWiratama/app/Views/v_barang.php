<tr>
  <td>
    <br>
    <h2>List barang</h2>
    <a href="barang/input"><button>Input</button></a>
    <br>
    <br>
    <form action="<?= route_to('barang.search'); ?>" method="POST">
      <?= csrf_field(); ?>
      <input type="text" placeholder="Search.." name="nama">
      <button type="submit">Search</button>
    </form>
    <br>
    <table border="1">
      <tr align="center">
        <td>Gambar</td>
        <td>Nama Barang</td>
        <td>Harga Barang</td>
        <td>Stok</td>
      </tr>
      <!-- Latihan 5 -->
      <?php foreach ($barang as $brg) { ?>
        <tr align="center">
        <td><img src="<?= '/uploads/foto/' . $brg['link_gambar']; ?>" alt="" width="250px" length="250px"></td>
          <td><?= $brg['nama_brg']; ?></td>
          <td>Rp. <?= $brg['harga_brg']; ?></td>
          <td><?= $brg['stok']; ?></td>
        </tr>
      <?php } ?>
    </table>
    <br>
    <a href="barang/grafik"><button>Grafik Harga</button></a>
  </td>
</tr>
