<?php

namespace App\Controllers;

use App\Models\m_barang;

class c_barang extends BaseController
{
    protected $barangModel;
    public function __construct()
    {
        $this->barangModel = new m_barang();
    }

    public function display()
    {
        $data['nama_barang'] = $this->request->getVar('nama_barang');
        $data['barang'] = $this->barangModel->getBarang($data);
        $data['title'] = "Barang";
        $data['content_view'] = "v_barang";

        echo view('v_template', $data);
    }

    public function input()
    {
        $data['content_view'] = "v_barang_input";
        $data['title'] = "Input Mahasiswa";

        echo view('v_template', $data);
    }

    public function store()
    {
        $data = [
            'nama_brg' => $this->request->getVar('nama_brg'),
            'harga_brg' => $this->request->getVar('harga_brg'),
            'stok' => $this->request->getVar('stok'),
            'link_gambar' => $this->request->getFile('link_gambar'),
        ];

        $result = $this->barangModel->storeBarang($data);

        if ($result) {
            session()->setFlashdata('pesan', 'Data berhasil ditambahkan');
            return redirect()->route('barang');
        }
    }

    function detail($id)
    {
        $data['barang'] = $this->barangModel->find($id);

        $data['content_view'] = "v_barang_detail";
        $data['title'] = "Detail Barang";

        echo view('v_template', $data);
    }

    function delete($id)
    {
        $barang = $this->barangModel->find($id);
        $this->barangModel->deleteBarang($barang);
        return redirect()->to('/barang');
    }

    public function update($id)
    {
        $data = [
            'nama_barang' => $this->request->getVar('nama_barang'),
            'harga_barang' => $this->request->getVar('harga_barang'),
            'stok' => $this->request->getVar('stok'),
            'link_gambar' => $this->request->getFile('link_gambar'),
        ];

        $barang_lama = $this->barangModel->find($id);
        $data['foto_lama'] = $barang_lama['link_gambar'];

        // dd($data);

        $result = $this->barangModel->updateBarang($data);

        if ($result) {
            session()->setFlashdata('pesan', 'Data berhasil diupdate');
            return redirect()->route('barang');
        }
    }

    public function edit($id)
    {
        $data['title'] = 'Edit Data Barang';
        $data['barang'] = $this->barangModel->find($id);
        $data['content_view'] = "v_barang_edit";
        echo view('v_template', $data);
    }
}
