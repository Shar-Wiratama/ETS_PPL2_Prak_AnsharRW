<?php

namespace App\Controllers;

use App\Models\m_mahasiswa;

class c_home extends BaseController
{

  protected $mahasiswaModel;
  public function __construct()
  {
    $this->barangModel = new m_barang();
  }

  public function display()
  {
    $data['content_view'] = "v_home";
    $data['title'] = "Home";

    $data['nama_barang'] = $this->request->getVar('nama_barang');
    $data['mahasiswa'] = $this->barangModel->getBarang($data);
    echo view('v_template', $data);
    // echo view('v_home');
  }
}
